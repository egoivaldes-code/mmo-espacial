# spacemmo_v0.0.3.zip — Sincronización + dos pantallas iniciales

Nota de versión: el v0.0.3 anterior nunca llegó a desplegarse, así que
este paquete lo sustituye por completo (no lo complementa) — sigue siendo
v0.0.3, no v0.0.4. El último desplegado de verdad es v0.0.2.

## Qué trae

### Sincronización
- Predicción local de movimiento + interpolación de jugadores remotos.
- Ping/latencia en pantalla.
- Reconexión automática si se cae la conexión.
- Límite visual del mundo jugable (con clamp real en el servidor).

### Dos pantallas iniciales (nuevo en este parche)
1. **Changelog + barra de carga**: se muestra el CHANGELOG.md scrolleable
   (entrada más reciente arriba), con una barra de estado FIJA abajo (no
   se mueve con el scroll) que va narrando la conexión: "Comprobando
   estado del servidor…" → "Despertando el servidor…" (si tarda) →
   "Conectando…" → "Conectado". El botón "Continuar" está siempre
   disponible, no espera a que termine de conectar.
2. **Selección/creación de personaje**: hasta 5 personajes, guardados en
   el navegador (localStorage — es un sustituto provisional hasta que
   haya cuentas de verdad vía Supabase, ver sección 7 del documento de
   diseño). Si no hay ninguno, pasa directo a crear uno. Si ya hay,
   aparecen listados con opción de crear uno nuevo (oculta si ya hay 5).

La conexión real al servidor arranca en segundo plano nada más cargar la
página — antes de que el jugador vea ninguna de las dos pantallas — así
que para cuando termina de leer el changelog y elegir personaje, lo normal
es que el servidor ya esté listo (o al menos haya avanzado bastante si
estaba dormido).

## Archivos que incluye

```
CHANGELOG.md                → raíz del repo, reemplaza el existente
client/public/CHANGELOG.md  → NUEVO — copia que Vite sirve como estático
                               para que el juego la muestre en pantalla 1
client/src/main.js          → reemplaza el existente
client/index.html           → reemplaza el existente
server/rooms/ChunkRoom.js   → reemplaza el existente (añade mensaje setName)
```

No toca `client/vite.config.js`, `server/index.js`, `server/schema/`, ni
el workflow de GitHub Actions.

## Cómo aplicarlo

- `CHANGELOG.md` → sobreescribe el de la raíz del repo.
- `client/public/CHANGELOG.md` → es un archivo NUEVO, créalo en esa ruta
  (la carpeta `client/public/` probablemente no existe todavía, créala).
- `client/src/main.js`, `client/index.html`, `server/rooms/ChunkRoom.js`
  → sobreescriben los existentes en sus mismas rutas.

Commit + push a `main`. El workflow de `deploy-pages` se dispara solo por
el cambio en `client/` y republica el sitio. El cambio en `server/`
necesita que Render vuelva a desplegar (automático si tienes auto-deploy
conectado al repo; si no, redeploy manual desde el dashboard de Render).
