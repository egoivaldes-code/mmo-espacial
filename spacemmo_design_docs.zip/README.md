# spacemmo_docs2.zip — Documento de diseño actualizado

Consolida en el documento de diseño todo lo decidido/aprendido durante el
desarrollo del prototipo que aún no estaba reflejado ahí (vivía disperso
en CHANGELOG.md y en la propia conversación):

- Nueva sección 5.2: sincronización cliente-servidor (predicción local +
  interpolación de remotos) como decisión de arquitectura, no solo un fix.
- Nota en sección 7: los personajes son un placeholder en localStorage,
  no persistencia real todavía (eso es Supabase, sigue pendiente).
- Sección 8.3 actualizada: la naveteca ya es editor (guardado local +
  exportar parche), no solo visor.
- Sección 11: cierra la pregunta abierta del tamaño de chunk (resuelta
  para el prototipo: 4000 unidades).
- Sección 13 (Roadmap) reescrita de arriba a abajo con el estado real del
  prototipo — la versión anterior describía un plan de fase 0 que ya se
  ha superado con creces.
- Nueva sección 14: infraestructura de desarrollo (hosting en
  Render/GitHub Pages, flujo de parches vía apply-patch.yml, política de
  versionado v0.0.X/v0.X) — decisiones prácticas que hasta ahora solo
  vivían en el README del repo o en el propio chat.

## Cómo aplicarlo

Sobreescribe `diseno-mmo-espacial.md` en la raíz del repo. No toca
`client/` ni `server/`, así que no debería disparar ningún deploy.
