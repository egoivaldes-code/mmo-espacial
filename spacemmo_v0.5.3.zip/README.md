# spacemmo_v0.5.3.zip — Dos fixes de interfaz en la pantalla de login

Solo cliente. Sin cambios de servidor ni de base de datos.

## 1. Botón "Crear cuenta" invisible

El CSS apuntaba a un `id` de la versión anterior (enlace mágico) que ya
no existe en el HTML. Corregido con estilos propios para
`#login-signin-btn` y `#login-signup-btn`.

## 2. La pantalla cambiaba de español a inglés de golpe

`#login-screen` no tenía estado oculto por defecto (a diferencia de la
pantalla de intro), así que se veía brevemente con el texto español
escrito a mano en el HTML antes de que la app aplicara el idioma
detectado del dispositivo. Corregido ocultándola por defecto igual que
las otras pantallas previas al juego.

Nota: el idioma detectado (inglés, en el caso que reportó el dueño del
proyecto) es el del navegador del dispositivo, no un fallo de detección.
Sigue pendiente de decidir si conviene que español gane siempre por
defecto — queda anotado en el documento de diseño (15.4.2).

## Documento de diseño

Añadido 15.4.2 con el relato de los dos fallos.
