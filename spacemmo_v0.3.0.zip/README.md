# spacemmo_v0.3.0.zip — Cuentas y persistencia real (Supabase)

Retira el sustituto de `localStorage`. Ahora hay cuentas de verdad,
personajes por cuenta y progreso guardado en servidor.

## Requisitos de despliegue

El servidor necesita dos variables de entorno en Render:

- `SUPABASE_URL` = https://knskhiyodnlocaiwqzmj.supabase.co
- `SUPABASE_SERVICE_ROLE_KEY` (o `SUPABASE_SERVICE_KEY`, se aceptan ambos)

Si faltan, el servidor arranca igual y el juego funciona SIN guardar,
avisando por consola. Es deliberado: una configuración incompleta deja el
juego jugable en vez de tirarlo abajo.

## Contenido

- `client/src/cuenta.js` (nuevo) — sesión y personajes contra Supabase.
- `server/persistence.js` (nuevo) — único módulo que habla con la base.
- Entrada por enlace mágico al correo, sin contraseñas.
- Carga del estado guardado al entrar y guardado cada 30 s, al salir, al
  expirar la reconexión y al cerrarse la sala.

## Seguridad

El navegador solo puede crear, listar y borrar sus propios personajes.
**No puede escribir posición, casco ni carga**: eso lo escribe únicamente
el servidor. Al entrar se verifica el testigo de sesión contra Supabase y
que el personaje pertenezca a esa cuenta.

## Documento de diseño

`diseno-mmo-espacial.md` incorpora la sección **7.1 (Persistencia real)**,
que sustituye al párrafo que describía el placeholder de `localStorage`.
