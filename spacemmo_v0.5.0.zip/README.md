# spacemmo_v0.5.0.zip — Primer combate jugable

Fijar objetivo, un arma, escudo/estructura/energía, y dos cruceros
enemigos con IA patrullando el sistema.

## Paso manual — migración de base de datos

Ya aplicada directamente contra Supabase durante esta sesión (columna
`shield` en `character_state`, nave inicial por defecto cambiada a
`cruiser_01`). No hace falta ejecutar nada: al desplegar este zip, los
personajes NUEVOS ya nacen como crucero. Los personajes EXISTENTES de
pruebas siguen con su `ship_id` guardado; si quieres que también pasen a
crucero, se actualiza a mano desde el SQL Editor de Supabase.

## Balance del combate

Verificado por simulación antes de fijarlo, no a ojo. El intento inicial
daba inmunidad orbitando pegado (162s sin daño); el balance final deja el
orbiteo como ventaja real y no absoluta. Detalle completo en
`diseno-mmo-espacial.md`, sección 8.4.10.2.

## Contenido

- `server/combat.js` (nuevo) — fórmulas de daño, separado de la sala.
- `server/schema/Npc.js` (nuevo) — schema replicado del enemigo.
- `server/rooms/ChunkRoom.js` — fijado, disparo, IA de NPC (4 Hz), muerte
  provisional (reaparece sin perder nada — falta inventario y seguro).
- `client/src/main.js`, `client/index.html` — barras de combate, botón de
  disparo, casilla de autodisparo, retículas de objetivo, números de daño.

## Pendiente conocido

- Muerte sin consecuencias: no se pierde la nave ni la carga (falta
  inventario, seguro, equidad de pérdida — 8.4).
- Un solo arma, un solo tamaño. Las otras familias entran encima sin
  rehacer nada (8.4.5).
- Sin resistencias por tipo de daño todavía.
