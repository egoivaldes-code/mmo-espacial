# spacemmo_v0.0.5.zip — Naveteca: de visor a editor

Requiere que v0.0.4 (client/public/ships/, client/public/naveteca/) ya
esté aplicado en el repo — este parche solo toca/reemplaza archivos que
v0.0.4 ya creó, no vuelve a incluir los 41 sprites/sonidos (sin cambios).

## Qué trae

- La naveteca (`client/public/naveteca/index.html`) pasa de solo-lectura
  a editor: cada nave se puede editar (nombre, clase, descripción, HP,
  velocidad, carga, tripulación) y sustituir su sprite (.png) o sonido
  (.mp3/.wav) desde la propia interfaz, con botón "Guardar cambios".
- Guardado en dos niveles (GitHub Pages es estático, no puede escribir en
  el repo):
  1. Local en `localStorage` del navegador — instantáneo, se refleja en
     la naveteca y en el juego real (misma clave de almacenamiento,
     mismo navegador) recargando la partida.
  2. Botón "Exportar parche" — genera un `.zip` con el `ships.json`
     fusionado + archivos sustituidos, listo para aplicar al repo con el
     flujo habitual y que lo vea todo el mundo.
- Versión en pantalla sube a `v0.0.5`.

## Archivos que incluye

```
CHANGELOG.md                       → raíz del repo, reemplaza el existente
client/src/main.js                 → reemplaza el existente
client/public/CHANGELOG.md         → reemplaza el existente
client/public/naveteca/index.html  → reemplaza el existente
```

No incluye `client/public/ships/` (sin cambios respecto a v0.0.4), ni
toca `server/`, `client/index.html`, `client/vite.config.js`, ni el
workflow de GitHub Actions.

## Cómo aplicarlo

Sobreescribe cada archivo en su misma ruta. Commit + push a `main`. El
workflow de `deploy-pages` se dispara solo por el cambio en `client/` y
republica el sitio.
