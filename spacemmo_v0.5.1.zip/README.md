# spacemmo_v0.5.1.zip — Fix crítico: el juego no arrancaba

v0.5.0 llegó a producción con un fallo que impedía crear cualquier sala.
Este parche lo corrige. Solo toca `server/rooms/ChunkRoom.js` y la
versión/changelog del cliente.

## Qué pasaba

Al unirse, el servidor lanzaba:
`Cannot read properties of undefined (reading 'set')`

El cliente lo mostraba como "error de conexión" genérico, lo que llevó a
sospechar primero de Supabase y de un desfase de versiones — verificado
que ninguna de las dos cosas era la causa.

## Causa real

`spawnNpc()` escribe en `this.npcBrains` (un Map con la IA de cada NPC).
`onCreate()` llamaba a `spawnNpc()` casi al principio del método, pero
`this.npcBrains = new Map()` se inicializaba más abajo, en el mismo
método. El NPC se creaba bien en el estado replicado y reventaba en la
siguiente línea, escribiendo sobre un Map que aún no existía.

## Corrección

Se mueve la creación de asteroides y NPCs al final de `onCreate()`,
después de que todas las piezas usadas por esos métodos ya existen.

## Verificación

No solo revisión de código: se reprodujo el fallo con un cliente Colyseus
real conectando contra una copia aislada de la sala, se confirmó la causa
exacta con depuración dirigida, y se volvió a probar la conexión completa
tras el arreglo (2 NPCs y 120 asteroides creados correctamente).

## Documento de diseño

Se añade 8.4.10.1.1 con el relato completo del fallo, como referencia
para no repetir el patrón: un método que depende de varias propiedades de
`this` es frágil si se llama antes de que `onCreate` acabe de inicializarlas
todas.
