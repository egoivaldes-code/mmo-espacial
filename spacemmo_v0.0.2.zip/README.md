# spacemmo_v0.0.2.zip — Parche combinado

Incluye dos cosas en un solo paquete:

## 1. CHANGELOG.md (nuevo, va en la RAÍZ del repo)

Registro de versiones + política de versionado (`v0.0.X` parches
pequeños, `v0.X` parches gordos). No existe todavía en el repo, así que
esto es un archivo nuevo, no un reemplazo.

## 2. Parche de cliente v0.0.2 (reemplaza archivos existentes en client/)

- `client/src/main.js` → reemplaza completo
- `client/index.html` → reemplaza completo

Contenido de este parche:
- Control móvil: joystick virtual que aparece donde el jugador toca la
  pantalla, con zona muerta central.
- Botón fijo "MINAR" abajo a la derecha, soporte multitouch (un dedo
  mueve, otro mina a la vez).
- Versión visible en pantalla (arriba a la derecha) y en el menú de
  opciones.
- Menú de opciones (botón "☰" arriba a la izquierda) con botón "Cerrar
  juego".
- Meta tags anticaché en `index.html`.
- **Fix**: la nave no se movía en el cliente porque `player.onChange`
  se usaba como asignación de propiedad en vez de llamarse como método de
  suscripción (`player.onChange(() => {...})`). Corregido.

## Estructura del zip

```
CHANGELOG.md
client/src/main.js
client/index.html
```

## Qué hacer con esto

- `CHANGELOG.md` → crear en la raíz del repo (no existe aún).
- `client/src/main.js` y `client/index.html` → sobreescribir los
  archivos existentes en esas mismas rutas dentro de `client/`.
- No tocar nada más (`server/`, `vite.config.js`, el workflow de GitHub
  Actions).
- Tras aplicar, commit + push a `main`. El workflow de `deploy-pages` se
  disparará solo por el cambio en `client/` y republicará el sitio.
