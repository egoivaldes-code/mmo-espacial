# spacemmo_v0.4.0.zip — Acceso con contraseña, dormido durante las pruebas

Sustituye el enlace mágico por correo y contraseña, y deja todo el sistema
apagado tras una constante mientras dure la fase de pruebas.

## Paso manual requerido

En Supabase → *Authentication* → *Sign In / Providers*:

- **Anonymous sign-ins**: ACTIVAR (necesario para entrar sin login).
- **Confirm email**: DESACTIVAR (necesario solo cuando se despierte el login).

Si las sesiones anónimas no están activadas, el juego no se rompe: enseña
la pantalla de login normal.

## Interruptor del login

`LOGIN_ENABLED` en `client/src/cuenta.js`.

- `false` (actual) — no se pide nada. Se crea una cuenta anónima al vuelo:
  una cuenta REAL de la base de datos, sin correo. Los personajes siguen
  en Supabase con su límite de 5, sus nombres únicos, sus reglas de
  escritura y su progreso guardado por el servidor.
- `true` — pantalla de correo y contraseña.

No se desactiva saltándose el sistema, y eso es deliberado: guardar los
personajes en el navegador durante el desarrollo crearía un segundo camino
que nadie prueba, y activar el login más tarde obligaría a revalidarlo
entero. Así, cada prueba recorre exactamente lo mismo que el juego final.

## Por qué se retira el enlace mágico

1. Obligaba a salir del juego para entrar al juego.
2. El correo de serie de Supabase solo envía mensajes a los dueños del
   proyecto. Funcionaba en pruebas porque el probador era el dueño; ningún
   otro jugador habría recibido nunca su enlace.

## Pendiente conocido

Sin servicio de correo propio no hay recuperación de contraseña. Es
requisito previo a abrir el juego a desconocidos; mientras tanto se
recupera a mano desde el panel de Supabase.

## Documento de diseño

Se amplía **7.1** con el motivo del cambio y se añade **7.1.1** (login
dormido, cuentas anónimas y cuándo despertarlo).
