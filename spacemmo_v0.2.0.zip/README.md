# spacemmo_v0.2.0.zip — Iconografía de interfaz y botón de acción contextual

Parche de interfaz. Añade el primer arte propio de HUD del proyecto y
convierte el botón de minar en un botón de acción que cambia según lo que
el jugador tenga a rango.

## Contenido

- **`client/public/ui/icons.png`** (nuevo) — atlas de 16 iconos, rejilla
  4×4 de 256 px con transparencia, 107 KB. Se usa como máscara CSS en el
  HUD HTML y como hoja de sprites en Phaser: una sola descarga para las
  dos capas.
- **Botón de acción contextual** — `mine` / `dock` / `gate` / `loot`
  según el objeto más cercano a rango. Lo decide el servidor y se envía
  por mensaje privado al cliente afectado, a 4 Hz y solo cuando cambia
  (no por el estado replicado de Colyseus, que se difunde a toda la sala).
- **Retícula giratoria** sobre el objetivo elegido, para desambiguar
  cuando hay varios objetos cerca.
- Asteroides con el icono del atlas en lugar de un círculo gris.
- Carga e integridad del casco en el HUD con icono en lugar de con las
  palabras "Carga:" y "HP:".
- Minado separado en dos conceptos: **poder** minar depende del módulo
  montado, **cuánto** extraes depende del casco. Ambos provisionales
  (todos llevan módulo, todos a ×1) hasta que existan módulos y clases.

## Documento de diseño

`diseno-mmo-espacial.md` incorpora la **sección 15 (Interfaz)** completa y
amplía **8.2 (Minado)** con los apartados 8.2.1 a 8.2.3: módulo abierto
con rendimiento desigual, los dos arquetipos de nave minera (autónoma e
industrial) y la dependencia dura de poder mover mineral entre naves en el
espacio.

Se añade al final (§15) a propósito, para no renumerar secciones: hay
referencias cruzadas por todo el documento que se romperían.
